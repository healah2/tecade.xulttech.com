# trainee/templatetags/custom_filters.py
from django import template

register = template.Library()

@register.filter
def get_item(dictionary, key):
    """
    Custom filter to get an item from a dictionary by its key.
    Usage: {{ submissions_dict|get_item:assignment.id }}
    """
    return dictionary.get(key)

@register.filter
def split(value, delimiter=','):
    """Split a string by delimiter and return list"""
    if value:
        return [item.strip() for item in value.split(delimiter) if item.strip()]
    return []    
